const employeesData = [
  {
    id: 1,
    firstName: "Vinay",
    lastName: "Palakonda",
    email: "Vinay@gmail.com",
    salary: "95000",
  },
  {
    id: 2,
    firstName: "Sai Harish",
    lastName: "Gurram",
    email: "saiharish@gmail.com",
    salary: "80000",
  
  },
  {
    id: 3,
    firstName: "Kesava Manikanta",
    lastName: "Vakkalagadda",
    email: "manikanta@gmail.com",
    salary: "60000",
  
  },
  {
    id: 4,
    firstName: "Amurutha",
    lastName: "Addisala",
    email: "amurutha@gmail.com",
    salary: "50000",
  
  },

];

  export { employeesData };