import React from "react";
import Dashboard from "./page/Dashboard";



function App() {

  return (
    <>
      <div>
        <Dashboard />
        
      </div>
    </>
  );
}

export default App;
